# The King of Gym Equipment CRM System

A comprehensive CRM system designed for gym equipment sales and management, built with modern web technologies.

## Features

### Core Functionality
- **Multi-language Support**: English, Hindi, and Gujarati language options
- **Responsive Design**: Fully optimized for iOS, Android, and web platforms
- **Animated UI**: Customizable animation speed settings for smooth user experience
- **Mobile-First**: Responsive hamburger menu and touch-optimized navigation

### System Update Mechanism
- **Live Updates**: Push updates from desktop that automatically reflect on all users' apps
- **Version Management**: Track and manage system versions with backend database
- **Smart Notifications**: Non-intrusive update notifications with version tracking
- **Auto-Reload**: Configurable automatic page reload for critical updates

### Business Management
- Dashboard with real-time KPI tracking
- Lead management and conversion tracking
- WhatsApp integration for customer communication
- Invoice generation and management
- Review management and monitoring
- Sales tracking and reporting

## Technology Stack

### Frontend
- **React 18.3.1**: Modern UI library with concurrent features
- **TypeScript 5.8.3**: Type-safe development
- **Vite 7.0.0**: Fast build tool and development server
- **Tailwind CSS 3.4.17**: Utility-first CSS framework
- **Framer Motion 11.0.8**: Advanced animation library
- **Zustand 4.4.7**: Lightweight state management

### Backend (Youware Backend)
- **Cloudflare Workers**: Serverless backend deployment
- **D1 Database**: SQLite-compatible database service
- **TypeScript**: Type-safe backend development

## Getting Started

### Prerequisites
- Node.js 18+ and npm
- Modern web browser

### Installation

```bash
# Install dependencies
npm install

# Build for production
npm run build
```

### Development
The project uses Vite for development and production builds. All source code is in the `src/` directory.

## System Update Management

### For Administrators
Create new system updates via the backend API:

```bash
# Create a new update
POST https://backend.youware.com/api/updates
Content-Type: application/json

{
  "version": "1.1.0",
  "title": "New Feature: Enhanced Dashboard",
  "description": "Added new KPI cards and improved data visualization",
  "update_type": "feature",
  "requires_reload": true
}
```

### Update Types
- **feature**: New functionality or enhancements
- **bugfix**: Bug fixes and corrections
- **design**: UI/UX improvements
- **performance**: Performance optimizations

### Automatic Distribution
When you create a new update:
1. The system stores it in the backend database
2. Frontend checks for updates every 60 seconds
3. Users see a notification about the new update
4. Users can choose to update immediately or later
5. If `requires_reload` is true, the page automatically reloads

## Project Structure

```
├── backend/                 # Backend API (Cloudflare Workers)
│   ├── src/
│   │   └── index.ts        # Main API endpoints
│   ├── wrangler.toml       # Worker configuration
│   ├── package.json        # Backend dependencies
│   └── schema.sql          # Database schema
├── src/                    # Frontend source code
│   ├── components/         # Reusable React components
│   │   ├── SettingsToolbar.tsx          # Language & animation settings
│   │   └── SystemUpdateNotification.tsx  # Update notification UI
│   ├── layouts/            # Layout components
│   │   └── MainLayout.tsx  # Main app layout with sidebar
│   ├── pages/              # Page components
│   ├── store/              # State management
│   │   ├── useSettings.ts  # Settings store (language, animation speed)
│   │   └── *Mock.ts        # Mock data stores
│   ├── types/              # TypeScript type definitions
│   └── App.tsx             # Main application component
├── dist/                   # Production build output
├── package.json            # Project dependencies
├── vite.config.ts          # Vite configuration
└── tailwind.config.js      # Tailwind CSS configuration
```

## Language Support

Currently supported languages:
- **English** (en) 🇺🇸
- **Hindi** (hi) 🇮🇳
- **Gujarati** (gu) 🇮🇳
- Chinese (zh) 🇨🇳
- Spanish (es) 🇪🇸
- Arabic (ar) 🇸🇦

Users can switch languages via the settings toolbar at the top of the application.

## Animation System

The application features a customizable animation speed system:
- **Slow (0.5×)**: Reduced speed for better visibility
- **Normal (1×)**: Default animation speed
- **Fast (1.5×)**: Quicker animations
- **Very Fast (2×)**: Rapid transitions

All Framer Motion animations throughout the app respect this setting.

## Backend API Endpoints

### Public Endpoints
- `GET /api/updates/latest` - Get the latest active update
- `GET /api/updates` - Get all active updates

### Admin Endpoints (Authentication Required)
- `POST /api/updates` - Create a new system update
- `DELETE /api/updates/:id` - Deactivate an update

## Database Schema

### system_updates Table
```sql
CREATE TABLE system_updates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  version TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  description TEXT,
  update_type TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  requires_reload INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
```

## Deployment

### Frontend Deployment
The frontend is automatically built and deployed through the Youware platform.

### Backend Deployment
Backend is deployed as a Cloudflare Worker:
```bash
cd backend
npm run deploy
```

## Contributing

This is a custom CRM system for The King of Gym Equipment. For feature requests or bug reports, please contact the development team.

## License

Proprietary - All rights reserved by The King of Gym Equipment
