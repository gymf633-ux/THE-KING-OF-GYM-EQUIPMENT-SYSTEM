var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};

// node_modules/unenv/dist/runtime/_internal/utils.mjs
function createNotImplementedError(name) {
  return new Error(`[unenv] ${name} is not implemented yet!`);
}
__name(createNotImplementedError, "createNotImplementedError");
function notImplemented(name) {
  const fn = /* @__PURE__ */ __name(() => {
    throw createNotImplementedError(name);
  }, "fn");
  return Object.assign(fn, { __unenv__: true });
}
__name(notImplemented, "notImplemented");
function notImplementedClass(name) {
  return class {
    __unenv__ = true;
    constructor() {
      throw new Error(`[unenv] ${name} is not implemented yet!`);
    }
  };
}
__name(notImplementedClass, "notImplementedClass");

// node_modules/unenv/dist/runtime/node/internal/perf_hooks/performance.mjs
var _timeOrigin = globalThis.performance?.timeOrigin ?? Date.now();
var _performanceNow = globalThis.performance?.now ? globalThis.performance.now.bind(globalThis.performance) : () => Date.now() - _timeOrigin;
var nodeTiming = {
  name: "node",
  entryType: "node",
  startTime: 0,
  duration: 0,
  nodeStart: 0,
  v8Start: 0,
  bootstrapComplete: 0,
  environment: 0,
  loopStart: 0,
  loopExit: 0,
  idleTime: 0,
  uvMetricsInfo: {
    loopCount: 0,
    events: 0,
    eventsWaiting: 0
  },
  detail: void 0,
  toJSON() {
    return this;
  }
};
var PerformanceEntry = class {
  __unenv__ = true;
  detail;
  entryType = "event";
  name;
  startTime;
  constructor(name, options) {
    this.name = name;
    this.startTime = options?.startTime || _performanceNow();
    this.detail = options?.detail;
  }
  get duration() {
    return _performanceNow() - this.startTime;
  }
  toJSON() {
    return {
      name: this.name,
      entryType: this.entryType,
      startTime: this.startTime,
      duration: this.duration,
      detail: this.detail
    };
  }
};
__name(PerformanceEntry, "PerformanceEntry");
var PerformanceMark = /* @__PURE__ */ __name(class PerformanceMark2 extends PerformanceEntry {
  entryType = "mark";
  constructor() {
    super(...arguments);
  }
  get duration() {
    return 0;
  }
}, "PerformanceMark");
var PerformanceMeasure = class extends PerformanceEntry {
  entryType = "measure";
};
__name(PerformanceMeasure, "PerformanceMeasure");
var PerformanceResourceTiming = class extends PerformanceEntry {
  entryType = "resource";
  serverTiming = [];
  connectEnd = 0;
  connectStart = 0;
  decodedBodySize = 0;
  domainLookupEnd = 0;
  domainLookupStart = 0;
  encodedBodySize = 0;
  fetchStart = 0;
  initiatorType = "";
  name = "";
  nextHopProtocol = "";
  redirectEnd = 0;
  redirectStart = 0;
  requestStart = 0;
  responseEnd = 0;
  responseStart = 0;
  secureConnectionStart = 0;
  startTime = 0;
  transferSize = 0;
  workerStart = 0;
  responseStatus = 0;
};
__name(PerformanceResourceTiming, "PerformanceResourceTiming");
var PerformanceObserverEntryList = class {
  __unenv__ = true;
  getEntries() {
    return [];
  }
  getEntriesByName(_name, _type) {
    return [];
  }
  getEntriesByType(type) {
    return [];
  }
};
__name(PerformanceObserverEntryList, "PerformanceObserverEntryList");
var Performance = class {
  __unenv__ = true;
  timeOrigin = _timeOrigin;
  eventCounts = /* @__PURE__ */ new Map();
  _entries = [];
  _resourceTimingBufferSize = 0;
  navigation = void 0;
  timing = void 0;
  timerify(_fn, _options) {
    throw createNotImplementedError("Performance.timerify");
  }
  get nodeTiming() {
    return nodeTiming;
  }
  eventLoopUtilization() {
    return {};
  }
  markResourceTiming() {
    return new PerformanceResourceTiming("");
  }
  onresourcetimingbufferfull = null;
  now() {
    if (this.timeOrigin === _timeOrigin) {
      return _performanceNow();
    }
    return Date.now() - this.timeOrigin;
  }
  clearMarks(markName) {
    this._entries = markName ? this._entries.filter((e) => e.name !== markName) : this._entries.filter((e) => e.entryType !== "mark");
  }
  clearMeasures(measureName) {
    this._entries = measureName ? this._entries.filter((e) => e.name !== measureName) : this._entries.filter((e) => e.entryType !== "measure");
  }
  clearResourceTimings() {
    this._entries = this._entries.filter((e) => e.entryType !== "resource" || e.entryType !== "navigation");
  }
  getEntries() {
    return this._entries;
  }
  getEntriesByName(name, type) {
    return this._entries.filter((e) => e.name === name && (!type || e.entryType === type));
  }
  getEntriesByType(type) {
    return this._entries.filter((e) => e.entryType === type);
  }
  mark(name, options) {
    const entry = new PerformanceMark(name, options);
    this._entries.push(entry);
    return entry;
  }
  measure(measureName, startOrMeasureOptions, endMark) {
    let start;
    let end;
    if (typeof startOrMeasureOptions === "string") {
      start = this.getEntriesByName(startOrMeasureOptions, "mark")[0]?.startTime;
      end = this.getEntriesByName(endMark, "mark")[0]?.startTime;
    } else {
      start = Number.parseFloat(startOrMeasureOptions?.start) || this.now();
      end = Number.parseFloat(startOrMeasureOptions?.end) || this.now();
    }
    const entry = new PerformanceMeasure(measureName, {
      startTime: start,
      detail: {
        start,
        end
      }
    });
    this._entries.push(entry);
    return entry;
  }
  setResourceTimingBufferSize(maxSize) {
    this._resourceTimingBufferSize = maxSize;
  }
  addEventListener(type, listener, options) {
    throw createNotImplementedError("Performance.addEventListener");
  }
  removeEventListener(type, listener, options) {
    throw createNotImplementedError("Performance.removeEventListener");
  }
  dispatchEvent(event) {
    throw createNotImplementedError("Performance.dispatchEvent");
  }
  toJSON() {
    return this;
  }
};
__name(Performance, "Performance");
var PerformanceObserver = class {
  __unenv__ = true;
  _callback = null;
  constructor(callback) {
    this._callback = callback;
  }
  takeRecords() {
    return [];
  }
  disconnect() {
    throw createNotImplementedError("PerformanceObserver.disconnect");
  }
  observe(options) {
    throw createNotImplementedError("PerformanceObserver.observe");
  }
  bind(fn) {
    return fn;
  }
  runInAsyncScope(fn, thisArg, ...args) {
    return fn.call(thisArg, ...args);
  }
  asyncId() {
    return 0;
  }
  triggerAsyncId() {
    return 0;
  }
  emitDestroy() {
    return this;
  }
};
__name(PerformanceObserver, "PerformanceObserver");
__publicField(PerformanceObserver, "supportedEntryTypes", []);
var performance = globalThis.performance && "addEventListener" in globalThis.performance ? globalThis.performance : new Performance();

// node_modules/@cloudflare/unenv-preset/dist/runtime/polyfill/performance.mjs
globalThis.performance = performance;
globalThis.Performance = Performance;
globalThis.PerformanceEntry = PerformanceEntry;
globalThis.PerformanceMark = PerformanceMark;
globalThis.PerformanceMeasure = PerformanceMeasure;
globalThis.PerformanceObserver = PerformanceObserver;
globalThis.PerformanceObserverEntryList = PerformanceObserverEntryList;
globalThis.PerformanceResourceTiming = PerformanceResourceTiming;

// node_modules/unenv/dist/runtime/node/console.mjs
import { Writable } from "node:stream";

// node_modules/unenv/dist/runtime/mock/noop.mjs
var noop_default = Object.assign(() => {
}, { __unenv__: true });

// node_modules/unenv/dist/runtime/node/console.mjs
var _console = globalThis.console;
var _ignoreErrors = true;
var _stderr = new Writable();
var _stdout = new Writable();
var log = _console?.log ?? noop_default;
var info = _console?.info ?? log;
var trace = _console?.trace ?? info;
var debug = _console?.debug ?? log;
var table = _console?.table ?? log;
var error = _console?.error ?? log;
var warn = _console?.warn ?? error;
var createTask = _console?.createTask ?? /* @__PURE__ */ notImplemented("console.createTask");
var clear = _console?.clear ?? noop_default;
var count = _console?.count ?? noop_default;
var countReset = _console?.countReset ?? noop_default;
var dir = _console?.dir ?? noop_default;
var dirxml = _console?.dirxml ?? noop_default;
var group = _console?.group ?? noop_default;
var groupEnd = _console?.groupEnd ?? noop_default;
var groupCollapsed = _console?.groupCollapsed ?? noop_default;
var profile = _console?.profile ?? noop_default;
var profileEnd = _console?.profileEnd ?? noop_default;
var time = _console?.time ?? noop_default;
var timeEnd = _console?.timeEnd ?? noop_default;
var timeLog = _console?.timeLog ?? noop_default;
var timeStamp = _console?.timeStamp ?? noop_default;
var Console = _console?.Console ?? /* @__PURE__ */ notImplementedClass("console.Console");
var _times = /* @__PURE__ */ new Map();
var _stdoutErrorHandler = noop_default;
var _stderrErrorHandler = noop_default;

// node_modules/@cloudflare/unenv-preset/dist/runtime/node/console.mjs
var workerdConsole = globalThis["console"];
var {
  assert,
  clear: clear2,
  // @ts-expect-error undocumented public API
  context,
  count: count2,
  countReset: countReset2,
  // @ts-expect-error undocumented public API
  createTask: createTask2,
  debug: debug2,
  dir: dir2,
  dirxml: dirxml2,
  error: error2,
  group: group2,
  groupCollapsed: groupCollapsed2,
  groupEnd: groupEnd2,
  info: info2,
  log: log2,
  profile: profile2,
  profileEnd: profileEnd2,
  table: table2,
  time: time2,
  timeEnd: timeEnd2,
  timeLog: timeLog2,
  timeStamp: timeStamp2,
  trace: trace2,
  warn: warn2
} = workerdConsole;
Object.assign(workerdConsole, {
  Console,
  _ignoreErrors,
  _stderr,
  _stderrErrorHandler,
  _stdout,
  _stdoutErrorHandler,
  _times
});
var console_default = workerdConsole;

// node_modules/wrangler/_virtual_unenv_global_polyfill-@cloudflare-unenv-preset-node-console
globalThis.console = console_default;

// node_modules/unenv/dist/runtime/node/internal/process/hrtime.mjs
var hrtime = /* @__PURE__ */ Object.assign(/* @__PURE__ */ __name(function hrtime2(startTime) {
  const now = Date.now();
  const seconds = Math.trunc(now / 1e3);
  const nanos = now % 1e3 * 1e6;
  if (startTime) {
    let diffSeconds = seconds - startTime[0];
    let diffNanos = nanos - startTime[0];
    if (diffNanos < 0) {
      diffSeconds = diffSeconds - 1;
      diffNanos = 1e9 + diffNanos;
    }
    return [diffSeconds, diffNanos];
  }
  return [seconds, nanos];
}, "hrtime"), { bigint: /* @__PURE__ */ __name(function bigint() {
  return BigInt(Date.now() * 1e6);
}, "bigint") });

// node_modules/unenv/dist/runtime/node/internal/process/process.mjs
import { EventEmitter } from "node:events";

// node_modules/unenv/dist/runtime/node/internal/tty/read-stream.mjs
import { Socket } from "node:net";
var ReadStream = class extends Socket {
  fd;
  constructor(fd) {
    super();
    this.fd = fd;
  }
  isRaw = false;
  setRawMode(mode) {
    this.isRaw = mode;
    return this;
  }
  isTTY = false;
};
__name(ReadStream, "ReadStream");

// node_modules/unenv/dist/runtime/node/internal/tty/write-stream.mjs
import { Socket as Socket2 } from "node:net";
var WriteStream = class extends Socket2 {
  fd;
  constructor(fd) {
    super();
    this.fd = fd;
  }
  clearLine(dir3, callback) {
    callback && callback();
    return false;
  }
  clearScreenDown(callback) {
    callback && callback();
    return false;
  }
  cursorTo(x, y, callback) {
    callback && typeof callback === "function" && callback();
    return false;
  }
  moveCursor(dx, dy, callback) {
    callback && callback();
    return false;
  }
  getColorDepth(env2) {
    return 1;
  }
  hasColors(count3, env2) {
    return false;
  }
  getWindowSize() {
    return [this.columns, this.rows];
  }
  columns = 80;
  rows = 24;
  isTTY = false;
};
__name(WriteStream, "WriteStream");

// node_modules/unenv/dist/runtime/node/internal/process/process.mjs
var Process = class extends EventEmitter {
  env;
  hrtime;
  nextTick;
  constructor(impl) {
    super();
    this.env = impl.env;
    this.hrtime = impl.hrtime;
    this.nextTick = impl.nextTick;
    for (const prop of [...Object.getOwnPropertyNames(Process.prototype), ...Object.getOwnPropertyNames(EventEmitter.prototype)]) {
      const value = this[prop];
      if (typeof value === "function") {
        this[prop] = value.bind(this);
      }
    }
  }
  emitWarning(warning, type, code) {
    console.warn(`${code ? `[${code}] ` : ""}${type ? `${type}: ` : ""}${warning}`);
  }
  emit(...args) {
    return super.emit(...args);
  }
  listeners(eventName) {
    return super.listeners(eventName);
  }
  #stdin;
  #stdout;
  #stderr;
  get stdin() {
    return this.#stdin ??= new ReadStream(0);
  }
  get stdout() {
    return this.#stdout ??= new WriteStream(1);
  }
  get stderr() {
    return this.#stderr ??= new WriteStream(2);
  }
  #cwd = "/";
  chdir(cwd2) {
    this.#cwd = cwd2;
  }
  cwd() {
    return this.#cwd;
  }
  arch = "";
  platform = "";
  argv = [];
  argv0 = "";
  execArgv = [];
  execPath = "";
  title = "";
  pid = 200;
  ppid = 100;
  get version() {
    return "";
  }
  get versions() {
    return {};
  }
  get allowedNodeEnvironmentFlags() {
    return /* @__PURE__ */ new Set();
  }
  get sourceMapsEnabled() {
    return false;
  }
  get debugPort() {
    return 0;
  }
  get throwDeprecation() {
    return false;
  }
  get traceDeprecation() {
    return false;
  }
  get features() {
    return {};
  }
  get release() {
    return {};
  }
  get connected() {
    return false;
  }
  get config() {
    return {};
  }
  get moduleLoadList() {
    return [];
  }
  constrainedMemory() {
    return 0;
  }
  availableMemory() {
    return 0;
  }
  uptime() {
    return 0;
  }
  resourceUsage() {
    return {};
  }
  ref() {
  }
  unref() {
  }
  umask() {
    throw createNotImplementedError("process.umask");
  }
  getBuiltinModule() {
    return void 0;
  }
  getActiveResourcesInfo() {
    throw createNotImplementedError("process.getActiveResourcesInfo");
  }
  exit() {
    throw createNotImplementedError("process.exit");
  }
  reallyExit() {
    throw createNotImplementedError("process.reallyExit");
  }
  kill() {
    throw createNotImplementedError("process.kill");
  }
  abort() {
    throw createNotImplementedError("process.abort");
  }
  dlopen() {
    throw createNotImplementedError("process.dlopen");
  }
  setSourceMapsEnabled() {
    throw createNotImplementedError("process.setSourceMapsEnabled");
  }
  loadEnvFile() {
    throw createNotImplementedError("process.loadEnvFile");
  }
  disconnect() {
    throw createNotImplementedError("process.disconnect");
  }
  cpuUsage() {
    throw createNotImplementedError("process.cpuUsage");
  }
  setUncaughtExceptionCaptureCallback() {
    throw createNotImplementedError("process.setUncaughtExceptionCaptureCallback");
  }
  hasUncaughtExceptionCaptureCallback() {
    throw createNotImplementedError("process.hasUncaughtExceptionCaptureCallback");
  }
  initgroups() {
    throw createNotImplementedError("process.initgroups");
  }
  openStdin() {
    throw createNotImplementedError("process.openStdin");
  }
  assert() {
    throw createNotImplementedError("process.assert");
  }
  binding() {
    throw createNotImplementedError("process.binding");
  }
  permission = { has: /* @__PURE__ */ notImplemented("process.permission.has") };
  report = {
    directory: "",
    filename: "",
    signal: "SIGUSR2",
    compact: false,
    reportOnFatalError: false,
    reportOnSignal: false,
    reportOnUncaughtException: false,
    getReport: /* @__PURE__ */ notImplemented("process.report.getReport"),
    writeReport: /* @__PURE__ */ notImplemented("process.report.writeReport")
  };
  finalization = {
    register: /* @__PURE__ */ notImplemented("process.finalization.register"),
    unregister: /* @__PURE__ */ notImplemented("process.finalization.unregister"),
    registerBeforeExit: /* @__PURE__ */ notImplemented("process.finalization.registerBeforeExit")
  };
  memoryUsage = Object.assign(() => ({
    arrayBuffers: 0,
    rss: 0,
    external: 0,
    heapTotal: 0,
    heapUsed: 0
  }), { rss: () => 0 });
  mainModule = void 0;
  domain = void 0;
  send = void 0;
  exitCode = void 0;
  channel = void 0;
  getegid = void 0;
  geteuid = void 0;
  getgid = void 0;
  getgroups = void 0;
  getuid = void 0;
  setegid = void 0;
  seteuid = void 0;
  setgid = void 0;
  setgroups = void 0;
  setuid = void 0;
  _events = void 0;
  _eventsCount = void 0;
  _exiting = void 0;
  _maxListeners = void 0;
  _debugEnd = void 0;
  _debugProcess = void 0;
  _fatalException = void 0;
  _getActiveHandles = void 0;
  _getActiveRequests = void 0;
  _kill = void 0;
  _preload_modules = void 0;
  _rawDebug = void 0;
  _startProfilerIdleNotifier = void 0;
  _stopProfilerIdleNotifier = void 0;
  _tickCallback = void 0;
  _disconnect = void 0;
  _handleQueue = void 0;
  _pendingMessage = void 0;
  _channel = void 0;
  _send = void 0;
  _linkedBinding = void 0;
};
__name(Process, "Process");

// node_modules/@cloudflare/unenv-preset/dist/runtime/node/process.mjs
var globalProcess = globalThis["process"];
var getBuiltinModule = globalProcess.getBuiltinModule;
var { exit, platform, nextTick } = getBuiltinModule(
  "node:process"
);
var unenvProcess = new Process({
  env: globalProcess.env,
  hrtime,
  nextTick
});
var {
  abort,
  addListener,
  allowedNodeEnvironmentFlags,
  hasUncaughtExceptionCaptureCallback,
  setUncaughtExceptionCaptureCallback,
  loadEnvFile,
  sourceMapsEnabled,
  arch,
  argv,
  argv0,
  chdir,
  config,
  connected,
  constrainedMemory,
  availableMemory,
  cpuUsage,
  cwd,
  debugPort,
  dlopen,
  disconnect,
  emit,
  emitWarning,
  env,
  eventNames,
  execArgv,
  execPath,
  finalization,
  features,
  getActiveResourcesInfo,
  getMaxListeners,
  hrtime: hrtime3,
  kill,
  listeners,
  listenerCount,
  memoryUsage,
  on,
  off,
  once,
  pid,
  ppid,
  prependListener,
  prependOnceListener,
  rawListeners,
  release,
  removeAllListeners,
  removeListener,
  report,
  resourceUsage,
  setMaxListeners,
  setSourceMapsEnabled,
  stderr,
  stdin,
  stdout,
  title,
  throwDeprecation,
  traceDeprecation,
  umask,
  uptime,
  version,
  versions,
  domain,
  initgroups,
  moduleLoadList,
  reallyExit,
  openStdin,
  assert: assert2,
  binding,
  send,
  exitCode,
  channel,
  getegid,
  geteuid,
  getgid,
  getgroups,
  getuid,
  setegid,
  seteuid,
  setgid,
  setgroups,
  setuid,
  permission,
  mainModule,
  _events,
  _eventsCount,
  _exiting,
  _maxListeners,
  _debugEnd,
  _debugProcess,
  _fatalException,
  _getActiveHandles,
  _getActiveRequests,
  _kill,
  _preload_modules,
  _rawDebug,
  _startProfilerIdleNotifier,
  _stopProfilerIdleNotifier,
  _tickCallback,
  _disconnect,
  _handleQueue,
  _pendingMessage,
  _channel,
  _send,
  _linkedBinding
} = unenvProcess;
var _process = {
  abort,
  addListener,
  allowedNodeEnvironmentFlags,
  hasUncaughtExceptionCaptureCallback,
  setUncaughtExceptionCaptureCallback,
  loadEnvFile,
  sourceMapsEnabled,
  arch,
  argv,
  argv0,
  chdir,
  config,
  connected,
  constrainedMemory,
  availableMemory,
  cpuUsage,
  cwd,
  debugPort,
  dlopen,
  disconnect,
  emit,
  emitWarning,
  env,
  eventNames,
  execArgv,
  execPath,
  exit,
  finalization,
  features,
  getBuiltinModule,
  getActiveResourcesInfo,
  getMaxListeners,
  hrtime: hrtime3,
  kill,
  listeners,
  listenerCount,
  memoryUsage,
  nextTick,
  on,
  off,
  once,
  pid,
  platform,
  ppid,
  prependListener,
  prependOnceListener,
  rawListeners,
  release,
  removeAllListeners,
  removeListener,
  report,
  resourceUsage,
  setMaxListeners,
  setSourceMapsEnabled,
  stderr,
  stdin,
  stdout,
  title,
  throwDeprecation,
  traceDeprecation,
  umask,
  uptime,
  version,
  versions,
  // @ts-expect-error old API
  domain,
  initgroups,
  moduleLoadList,
  reallyExit,
  openStdin,
  assert: assert2,
  binding,
  send,
  exitCode,
  channel,
  getegid,
  geteuid,
  getgid,
  getgroups,
  getuid,
  setegid,
  seteuid,
  setgid,
  setgroups,
  setuid,
  permission,
  mainModule,
  _events,
  _eventsCount,
  _exiting,
  _maxListeners,
  _debugEnd,
  _debugProcess,
  _fatalException,
  _getActiveHandles,
  _getActiveRequests,
  _kill,
  _preload_modules,
  _rawDebug,
  _startProfilerIdleNotifier,
  _stopProfilerIdleNotifier,
  _tickCallback,
  _disconnect,
  _handleQueue,
  _pendingMessage,
  _channel,
  _send,
  _linkedBinding
};
var process_default = _process;

// node_modules/wrangler/_virtual_unenv_global_polyfill-@cloudflare-unenv-preset-node-process
globalThis.process = process_default;

// src/oauth/googleOAuth.ts
function getOAuthConfig(env2) {
  return {
    clientId: env2.GOOGLE_CLIENT_ID || "",
    clientSecret: env2.GOOGLE_CLIENT_SECRET || "",
    redirectUri: "https://backend.youware.com/api/oauth2/google/callback",
    authEndpoint: "https://accounts.google.com/o/oauth2/v2/auth",
    tokenEndpoint: "https://oauth2.googleapis.com/token",
    scopes: [
      "https://www.googleapis.com/auth/business.manage",
      "https://www.googleapis.com/auth/plus.business.manage"
    ]
  };
}
__name(getOAuthConfig, "getOAuthConfig");
function validateOAuthConfig(env2) {
  return !!(env2.GOOGLE_CLIENT_ID && env2.GOOGLE_CLIENT_SECRET);
}
__name(validateOAuthConfig, "validateOAuthConfig");
function generateState() {
  const array = new Uint8Array(32);
  crypto.getRandomValues(array);
  return Array.from(array, (byte) => byte.toString(16).padStart(2, "0")).join("");
}
__name(generateState, "generateState");
async function storeOAuthState(env2, state, userId) {
  const stmt = env2.DB.prepare(
    `INSERT INTO oauth_states (state, user_id, created_at, expires_at)
     VALUES (?, ?, datetime('now'), datetime('now', '+10 minutes'))`
  );
  await stmt.bind(state, userId || null).run();
}
__name(storeOAuthState, "storeOAuthState");
async function validateOAuthState(env2, state) {
  const stmt = env2.DB.prepare(
    `SELECT * FROM oauth_states 
     WHERE state = ? 
     AND expires_at > datetime('now')`
  );
  const result = await stmt.bind(state).first();
  if (result) {
    const deleteStmt = env2.DB.prepare("DELETE FROM oauth_states WHERE state = ?");
    await deleteStmt.bind(state).run();
    return true;
  }
  return false;
}
__name(validateOAuthState, "validateOAuthState");
async function exchangeCodeForToken(env2, code) {
  const config2 = getOAuthConfig(env2);
  const response = await fetch(config2.tokenEndpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: new URLSearchParams({
      code,
      client_id: config2.clientId,
      client_secret: config2.clientSecret,
      redirect_uri: config2.redirectUri,
      grant_type: "authorization_code"
    })
  });
  if (!response.ok) {
    const error3 = await response.text();
    throw new Error(`Token exchange failed: ${error3}`);
  }
  return await response.json();
}
__name(exchangeCodeForToken, "exchangeCodeForToken");
async function storeTokens(env2, tokens) {
  const expiryDate = new Date(Date.now() + tokens.expires_in * 1e3).toISOString();
  const stmt = env2.DB.prepare(
    `INSERT INTO settings (id, business_profile, whatsapp_api, gbp_api, pricing, notification_prefs)
     VALUES (1, '{}', '{}', ?, '{}', '{}')
     ON CONFLICT(id) DO UPDATE SET gbp_api = ?, updated_at = datetime('now')`
  );
  const config2 = {
    access_token: tokens.access_token,
    refresh_token: tokens.refresh_token,
    token_expiry: expiryDate,
    scope: tokens.scope
  };
  const configJson = JSON.stringify(config2);
  await stmt.bind(configJson, configJson).run();
}
__name(storeTokens, "storeTokens");
async function initiateOAuth(env2, userId) {
  if (!validateOAuthConfig(env2)) {
    console.error("OAuth credentials not configured. Please set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET.");
    return null;
  }
  const config2 = getOAuthConfig(env2);
  const state = generateState();
  await storeOAuthState(env2, state, userId);
  const params = new URLSearchParams({
    client_id: config2.clientId,
    redirect_uri: config2.redirectUri,
    response_type: "code",
    scope: config2.scopes.join(" "),
    state,
    access_type: "offline",
    // Request refresh token
    prompt: "consent"
    // Force consent screen to get refresh token
  });
  return `${config2.authEndpoint}?${params.toString()}`;
}
__name(initiateOAuth, "initiateOAuth");
async function handleOAuthCallback(env2, code, state) {
  try {
    const isValidState = await validateOAuthState(env2, state);
    if (!isValidState) {
      return { success: false, error: "Invalid or expired state parameter" };
    }
    if (!validateOAuthConfig(env2)) {
      return { success: false, error: "OAuth credentials not configured" };
    }
    const tokens = await exchangeCodeForToken(env2, code);
    await storeTokens(env2, tokens);
    return { success: true };
  } catch (error3) {
    console.error("OAuth callback error:", error3);
    return { success: false, error: error3.message };
  }
}
__name(handleOAuthCallback, "handleOAuthCallback");

// src/index.ts
var corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Project-Id, X-Encrypted-Yw-ID, X-Is-Login, X-Yw-Env"
};
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json",
      ...corsHeaders
    }
  });
}
__name(jsonResponse, "jsonResponse");
function errorResponse(message, status = 400) {
  return jsonResponse({ error: message }, status);
}
__name(errorResponse, "errorResponse");
async function getGBPConfig(env2) {
  const stmt = env2.DB.prepare("SELECT gbp_api FROM settings WHERE id = 1");
  const result = await stmt.first();
  if (!result) {
    return {};
  }
  try {
    return JSON.parse(result.gbp_api);
  } catch {
    return {};
  }
}
__name(getGBPConfig, "getGBPConfig");
async function updateGBPConfig(env2, config2) {
  const currentConfig = await getGBPConfig(env2);
  const newConfig = { ...currentConfig, ...config2 };
  const stmt = env2.DB.prepare(
    `INSERT INTO settings (id, business_profile, whatsapp_api, gbp_api, pricing, notification_prefs)
     VALUES (1, '{}', '{}', ?, '{}', '{}')
     ON CONFLICT(id) DO UPDATE SET gbp_api = ?, updated_at = datetime('now')`
  );
  const configJson = JSON.stringify(newConfig);
  await stmt.bind(configJson, configJson).run();
}
__name(updateGBPConfig, "updateGBPConfig");
var src_default = {
  async fetch(request, env2) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;
    if (method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders });
    }
    try {
      if (path === "/api/oauth2/google/auth" && method === "GET") {
        const userId = request.headers.get("X-Encrypted-Yw-ID");
        const authUrl = await initiateOAuth(env2, userId || void 0);
        if (!authUrl) {
          return errorResponse("OAuth credentials not configured. Please set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET environment variables.", 500);
        }
        return jsonResponse({
          success: true,
          auth_url: authUrl
        });
      }
      if (path === "/api/oauth2/google/callback" && method === "GET") {
        const code = url.searchParams.get("code");
        const state = url.searchParams.get("state");
        const error3 = url.searchParams.get("error");
        if (error3) {
          return new Response(null, {
            status: 302,
            headers: {
              "Location": `/?oauth=error&message=${encodeURIComponent(error3)}`,
              ...corsHeaders
            }
          });
        }
        if (!code || !state) {
          return new Response(null, {
            status: 302,
            headers: {
              "Location": "/?oauth=error&message=Missing+code+or+state",
              ...corsHeaders
            }
          });
        }
        const result = await handleOAuthCallback(env2, code, state);
        if (result.success) {
          return new Response(null, {
            status: 302,
            headers: {
              "Location": "/?oauth=success",
              ...corsHeaders
            }
          });
        } else {
          return new Response(null, {
            status: 302,
            headers: {
              "Location": `/?oauth=error&message=${encodeURIComponent(result.error || "Unknown error")}`,
              ...corsHeaders
            }
          });
        }
      }
      if (path === "/api/gbp/config" && method === "GET") {
        const config2 = await getGBPConfig(env2);
        return jsonResponse({
          success: true,
          configured: !!(config2.api_key || config2.access_token),
          has_account: !!config2.account_id,
          has_location: !!config2.location_id,
          token_expiry: config2.token_expiry || null
        });
      }
      if (path === "/api/gbp/config" && method === "POST") {
        const body = await request.json();
        await updateGBPConfig(env2, body);
        return jsonResponse({
          success: true,
          message: "GBP API configuration updated"
        });
      }
      if (path === "/api/gbp/fetch-analytics" && method === "POST") {
        const config2 = await getGBPConfig(env2);
        if (!config2.api_key && !config2.access_token) {
          return errorResponse("Google Business Profile API not configured", 401);
        }
        const body = await request.json();
        const startDate = body.start_date || new Date(Date.now() - 30 * 24 * 60 * 60 * 1e3).toISOString().split("T")[0];
        const endDate = body.end_date || (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
        const apiUrl = `https://mybusiness.googleapis.com/v4/accounts/${config2.account_id}/locations/${config2.location_id}/insights`;
        const authHeader = config2.access_token ? `Bearer ${config2.access_token}` : `Bearer ${config2.api_key}`;
        try {
          const response = await fetch(apiUrl, {
            method: "POST",
            headers: {
              "Authorization": authHeader,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              locationNames: [`accounts/${config2.account_id}/locations/${config2.location_id}`],
              basicRequest: {
                metricRequests: [
                  { metric: "QUERIES_DIRECT" },
                  { metric: "QUERIES_INDIRECT" },
                  { metric: "VIEWS_MAPS" },
                  { metric: "VIEWS_SEARCH" },
                  { metric: "ACTIONS_WEBSITE" },
                  { metric: "ACTIONS_PHONE" },
                  { metric: "ACTIONS_DRIVING_DIRECTIONS" }
                ],
                timeRange: {
                  startTime: `${startDate}T00:00:00Z`,
                  endTime: `${endDate}T23:59:59Z`
                }
              }
            })
          });
          if (!response.ok) {
            const errorData = await response.text();
            console.error("Google API Error:", errorData);
            return errorResponse(`Google API error: ${response.status}`, response.status);
          }
          const data = await response.json();
          const metricsData = data.locationMetrics?.[0]?.metricValues || [];
          const dailyMetrics = {};
          metricsData.forEach((metric) => {
            const metricName = metric.metric;
            metric.dimensionalValues?.forEach((value) => {
              const date = value.time?.split("T")[0];
              if (!date)
                return;
              if (!dailyMetrics[date]) {
                dailyMetrics[date] = {
                  date,
                  profile_views: 0,
                  profile_calls: 0,
                  direction_requests: 0,
                  website_clicks: 0,
                  photo_views: 0,
                  search_queries: 0
                };
              }
              const count3 = parseInt(value.value || "0");
              switch (metricName) {
                case "QUERIES_DIRECT":
                case "QUERIES_INDIRECT":
                  dailyMetrics[date].search_queries += count3;
                  break;
                case "VIEWS_MAPS":
                case "VIEWS_SEARCH":
                  dailyMetrics[date].profile_views += count3;
                  break;
                case "ACTIONS_WEBSITE":
                  dailyMetrics[date].website_clicks = count3;
                  break;
                case "ACTIONS_PHONE":
                  dailyMetrics[date].profile_calls = count3;
                  break;
                case "ACTIONS_DRIVING_DIRECTIONS":
                  dailyMetrics[date].direction_requests = count3;
                  break;
              }
            });
          });
          const statements = Object.values(dailyMetrics).map((metrics) => {
            const stmt = env2.DB.prepare(
              `INSERT INTO gbp_analytics (date, profile_views, profile_calls, direction_requests, website_clicks, photo_views, search_queries)
               VALUES (?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(date) DO UPDATE SET
                 profile_views = excluded.profile_views,
                 profile_calls = excluded.profile_calls,
                 direction_requests = excluded.direction_requests,
                 website_clicks = excluded.website_clicks,
                 photo_views = excluded.photo_views,
                 search_queries = excluded.search_queries,
                 updated_at = datetime('now')`
            );
            return stmt.bind(
              metrics.date,
              metrics.profile_views,
              metrics.profile_calls,
              metrics.direction_requests,
              metrics.website_clicks,
              metrics.photo_views,
              metrics.search_queries
            );
          });
          await env2.DB.batch(statements);
          return jsonResponse({
            success: true,
            message: "Analytics fetched and stored successfully",
            records_updated: Object.keys(dailyMetrics).length,
            date_range: { start: startDate, end: endDate }
          });
        } catch (apiError) {
          console.error("Google API fetch error:", apiError);
          return errorResponse(`Failed to fetch from Google API: ${apiError.message}`, 500);
        }
      }
      if (path === "/api/updates/latest" && method === "GET") {
        const stmt = env2.DB.prepare(
          "SELECT * FROM system_updates WHERE is_active = 1 ORDER BY created_at DESC LIMIT 1"
        );
        const result = await stmt.first();
        return jsonResponse({
          success: true,
          update: result || null
        });
      }
      if (path === "/api/updates" && method === "GET") {
        const stmt = env2.DB.prepare(
          "SELECT * FROM system_updates WHERE is_active = 1 ORDER BY created_at DESC"
        );
        const { results } = await stmt.all();
        return jsonResponse({
          success: true,
          updates: results
        });
      }
      if (path === "/api/updates" && method === "POST") {
        const adminYwId = request.headers.get("X-Admin-Encrypted-Yw-ID");
        const userYwId = request.headers.get("X-Encrypted-Yw-ID");
        if (!userYwId) {
          return errorResponse("Authentication required", 401);
        }
        const body = await request.json();
        if (!body.version || !body.title || !body.update_type) {
          return errorResponse("Missing required fields: version, title, update_type");
        }
        const stmt = env2.DB.prepare(
          `INSERT INTO system_updates (version, title, description, update_type, requires_reload)
           VALUES (?, ?, ?, ?, ?)`
        );
        await stmt.bind(
          body.version,
          body.title,
          body.description || null,
          body.update_type,
          body.requires_reload ? 1 : 0
        ).run();
        return jsonResponse({
          success: true,
          message: "Update created successfully"
        }, 201);
      }
      if (path.startsWith("/api/updates/") && method === "DELETE") {
        const userYwId = request.headers.get("X-Encrypted-Yw-ID");
        if (!userYwId) {
          return errorResponse("Authentication required", 401);
        }
        const updateId = path.split("/").pop();
        const stmt = env2.DB.prepare(
          "UPDATE system_updates SET is_active = 0, updated_at = datetime('now') WHERE id = ?"
        );
        await stmt.bind(updateId).run();
        return jsonResponse({
          success: true,
          message: "Update deactivated successfully"
        });
      }
      if (path === "/api/gbp/posts" && method === "GET") {
        const stmt = env2.DB.prepare(
          "SELECT * FROM gbp_posts ORDER BY created_at DESC"
        );
        const { results } = await stmt.all();
        return jsonResponse({
          success: true,
          posts: results
        });
      }
      if (path === "/api/gbp/posts" && method === "POST") {
        const body = await request.json();
        if (!body.post_type || !body.title || !body.body) {
          return errorResponse("Missing required fields: post_type, title, body");
        }
        const stmt = env2.DB.prepare(
          `INSERT INTO gbp_posts (post_type, title, body, media_url, scheduled_at, posted_at)
           VALUES (?, ?, ?, ?, ?, ?)`
        );
        const result = await stmt.bind(
          body.post_type,
          body.title,
          body.body,
          body.media_url || null,
          body.scheduled_at || null,
          body.posted_at || null
        ).run();
        return jsonResponse({
          success: true,
          message: "Post created successfully",
          post_id: result.meta.last_row_id
        }, 201);
      }
      if (path.startsWith("/api/gbp/posts/") && method === "PUT") {
        const postId = path.split("/").pop();
        const body = await request.json();
        const updates = [];
        const values = [];
        if (body.post_type) {
          updates.push("post_type = ?");
          values.push(body.post_type);
        }
        if (body.title) {
          updates.push("title = ?");
          values.push(body.title);
        }
        if (body.body) {
          updates.push("body = ?");
          values.push(body.body);
        }
        if (body.media_url !== void 0) {
          updates.push("media_url = ?");
          values.push(body.media_url);
        }
        if (body.scheduled_at !== void 0) {
          updates.push("scheduled_at = ?");
          values.push(body.scheduled_at);
        }
        if (body.posted_at !== void 0) {
          updates.push("posted_at = ?");
          values.push(body.posted_at);
        }
        if (updates.length === 0) {
          return errorResponse("No fields to update");
        }
        updates.push("updated_at = datetime('now')");
        values.push(postId);
        const stmt = env2.DB.prepare(
          `UPDATE gbp_posts SET ${updates.join(", ")} WHERE id = ?`
        );
        await stmt.bind(...values).run();
        return jsonResponse({
          success: true,
          message: "Post updated successfully"
        });
      }
      if (path.startsWith("/api/gbp/posts/") && method === "DELETE") {
        const postId = path.split("/").pop();
        const stmt = env2.DB.prepare("DELETE FROM gbp_posts WHERE id = ?");
        await stmt.bind(postId).run();
        return jsonResponse({
          success: true,
          message: "Post deleted successfully"
        });
      }
      if (path === "/api/competitors" && method === "GET") {
        const stmt = env2.DB.prepare(
          "SELECT * FROM competitors ORDER BY rank_position ASC"
        );
        const { results } = await stmt.all();
        const competitors = results.map((comp) => ({
          ...comp,
          keywords: JSON.parse(comp.keywords)
        }));
        return jsonResponse({
          success: true,
          competitors
        });
      }
      if (path === "/api/competitors" && method === "POST") {
        const body = await request.json();
        if (!body.name || !body.keywords || !body.rank_position) {
          return errorResponse("Missing required fields: name, keywords, rank_position");
        }
        const stmt = env2.DB.prepare(
          `INSERT INTO competitors (name, keywords, rank_position, last_checked_at)
           VALUES (?, ?, ?, datetime('now'))`
        );
        const result = await stmt.bind(
          body.name,
          JSON.stringify(body.keywords),
          body.rank_position
        ).run();
        return jsonResponse({
          success: true,
          message: "Competitor created successfully",
          competitor_id: result.meta.last_row_id
        }, 201);
      }
      if (path.startsWith("/api/competitors/") && method === "PUT") {
        const competitorId = path.split("/").pop();
        const body = await request.json();
        const updates = [];
        const values = [];
        if (body.name) {
          updates.push("name = ?");
          values.push(body.name);
        }
        if (body.keywords) {
          updates.push("keywords = ?");
          values.push(JSON.stringify(body.keywords));
        }
        if (body.rank_position) {
          updates.push("rank_position = ?");
          values.push(body.rank_position);
        }
        if (body.last_checked_at) {
          updates.push("last_checked_at = ?");
          values.push(body.last_checked_at);
        }
        if (updates.length === 0) {
          return errorResponse("No fields to update");
        }
        updates.push("updated_at = datetime('now')");
        values.push(competitorId);
        const stmt = env2.DB.prepare(
          `UPDATE competitors SET ${updates.join(", ")} WHERE id = ?`
        );
        await stmt.bind(...values).run();
        return jsonResponse({
          success: true,
          message: "Competitor updated successfully"
        });
      }
      if (path.startsWith("/api/competitors/") && method === "DELETE") {
        const competitorId = path.split("/").pop();
        const stmt = env2.DB.prepare("DELETE FROM competitors WHERE id = ?");
        await stmt.bind(competitorId).run();
        return jsonResponse({
          success: true,
          message: "Competitor deleted successfully"
        });
      }
      if (path === "/api/gbp/analytics" && method === "GET") {
        const days = url.searchParams.get("days") || "30";
        const stmt = env2.DB.prepare(
          `SELECT * FROM gbp_analytics 
           WHERE date >= date('now', '-' || ? || ' days')
           ORDER BY date DESC`
        );
        const { results } = await stmt.bind(days).all();
        return jsonResponse({
          success: true,
          analytics: results
        });
      }
      if (path === "/api/gbp/analytics" && method === "POST") {
        const body = await request.json();
        if (!body.date) {
          return errorResponse("Missing required field: date");
        }
        const stmt = env2.DB.prepare(
          `INSERT INTO gbp_analytics (date, profile_views, profile_calls, direction_requests, website_clicks, photo_views, search_queries)
           VALUES (?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(date) DO UPDATE SET
             profile_views = excluded.profile_views,
             profile_calls = excluded.profile_calls,
             direction_requests = excluded.direction_requests,
             website_clicks = excluded.website_clicks,
             photo_views = excluded.photo_views,
             search_queries = excluded.search_queries,
             updated_at = datetime('now')`
        );
        await stmt.bind(
          body.date,
          body.profile_views || 0,
          body.profile_calls || 0,
          body.direction_requests || 0,
          body.website_clicks || 0,
          body.photo_views || 0,
          body.search_queries || 0
        ).run();
        return jsonResponse({
          success: true,
          message: "Analytics updated successfully"
        }, 201);
      }
      if (path === "/api/seo/keywords" && method === "GET") {
        const activeOnly = url.searchParams.get("active") === "true";
        let query = "SELECT * FROM seo_keywords";
        if (activeOnly) {
          query += " WHERE is_active = 1";
        }
        query += " ORDER BY relevance_score DESC";
        const stmt = env2.DB.prepare(query);
        const { results } = await stmt.all();
        return jsonResponse({
          success: true,
          keywords: results
        });
      }
      if (path === "/api/seo/keywords" && method === "POST") {
        const body = await request.json();
        if (!body.keyword || !body.competition) {
          return errorResponse("Missing required fields: keyword, competition");
        }
        const stmt = env2.DB.prepare(
          `INSERT INTO seo_keywords (keyword, search_volume, competition, relevance_score, target_rank)
           VALUES (?, ?, ?, ?, ?)`
        );
        const result = await stmt.bind(
          body.keyword,
          body.search_volume || 0,
          body.competition,
          body.relevance_score || 0,
          body.target_rank || null
        ).run();
        return jsonResponse({
          success: true,
          message: "Keyword added successfully",
          keyword_id: result.meta.last_row_id
        }, 201);
      }
      if (path.startsWith("/api/seo/keywords/") && method === "PUT") {
        const keywordId = path.split("/").pop();
        const body = await request.json();
        const updates = [];
        const values = [];
        if (body.keyword) {
          updates.push("keyword = ?");
          values.push(body.keyword);
        }
        if (body.search_volume !== void 0) {
          updates.push("search_volume = ?");
          values.push(body.search_volume);
        }
        if (body.competition) {
          updates.push("competition = ?");
          values.push(body.competition);
        }
        if (body.relevance_score !== void 0) {
          updates.push("relevance_score = ?");
          values.push(body.relevance_score);
        }
        if (body.current_rank !== void 0) {
          updates.push("current_rank = ?");
          values.push(body.current_rank);
        }
        if (body.target_rank !== void 0) {
          updates.push("target_rank = ?");
          values.push(body.target_rank);
        }
        if (body.is_active !== void 0) {
          updates.push("is_active = ?");
          values.push(body.is_active);
        }
        if (updates.length === 0) {
          return errorResponse("No fields to update");
        }
        updates.push("updated_at = datetime('now')");
        values.push(keywordId);
        const stmt = env2.DB.prepare(
          `UPDATE seo_keywords SET ${updates.join(", ")} WHERE id = ?`
        );
        await stmt.bind(...values).run();
        return jsonResponse({
          success: true,
          message: "Keyword updated successfully"
        });
      }
      if (path.startsWith("/api/seo/keywords/") && method === "DELETE") {
        const keywordId = path.split("/").pop();
        const stmt = env2.DB.prepare("DELETE FROM seo_keywords WHERE id = ?");
        await stmt.bind(keywordId).run();
        return jsonResponse({
          success: true,
          message: "Keyword deleted successfully"
        });
      }
      if (path === "/api/gbp/publish" && method === "POST") {
        const body = await request.json();
        if (!body.post_id) {
          return errorResponse("Missing required field: post_id");
        }
        const postStmt = env2.DB.prepare("SELECT * FROM gbp_posts WHERE id = ?");
        const post = await postStmt.bind(body.post_id).first();
        if (!post) {
          return errorResponse("Post not found", 404);
        }
        const config2 = await getGBPConfig(env2);
        if (!config2.api_key && !config2.access_token) {
          return errorResponse("Google Business Profile API not configured", 401);
        }
        const apiUrl = `https://mybusiness.googleapis.com/v4/accounts/${config2.account_id}/locations/${config2.location_id}/localPosts`;
        const authHeader = config2.access_token ? `Bearer ${config2.access_token}` : `Bearer ${config2.api_key}`;
        const topicTypeMap = {
          "offer": "OFFER",
          "update": "STANDARD",
          "article": "EVENT"
        };
        try {
          const response = await fetch(apiUrl, {
            method: "POST",
            headers: {
              "Authorization": authHeader,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              languageCode: "en",
              summary: post.title,
              callToAction: {
                actionType: "LEARN_MORE",
                url: post.body.match(/https?:\/\/[^\s]+/)?.[0] || ""
              },
              topicType: topicTypeMap[post.post_type] || "STANDARD",
              ...post.media_url && {
                media: [{
                  mediaFormat: "PHOTO",
                  sourceUrl: post.media_url
                }]
              }
            })
          });
          if (!response.ok) {
            const errorData = await response.text();
            console.error("Google API Error:", errorData);
            return errorResponse(`Failed to publish post: ${response.status}`, response.status);
          }
          const publishedPost = await response.json();
          const updateStmt = env2.DB.prepare(
            `UPDATE gbp_posts SET posted_at = datetime('now'), updated_at = datetime('now') WHERE id = ?`
          );
          await updateStmt.bind(body.post_id).run();
          return jsonResponse({
            success: true,
            message: "Post published to Google Business Profile",
            post_id: body.post_id,
            google_post_id: publishedPost.name,
            published_at: (/* @__PURE__ */ new Date()).toISOString()
          });
        } catch (apiError) {
          console.error("Google API publish error:", apiError);
          return errorResponse(`Failed to publish: ${apiError.message}`, 500);
        }
      }
      if (path === "/api/verify/token" && method === "POST") {
        try {
          const body = await request.json();
          const testToken = body.test_token;
          if (!testToken) {
            return errorResponse("Missing test_token parameter", 400);
          }
          const isValidFormat = /^ya29\.[a-zA-Z0-9_-]+$/.test(testToken);
          if (!isValidFormat) {
            return jsonResponse({
              success: false,
              valid: false,
              error: "Invalid token format",
              message: "Token must start with ya29. and contain valid characters"
            });
          }
          const config2 = await getGBPConfig(env2);
          const isStoredToken = config2.access_token === testToken;
          let isExpired = false;
          if (isStoredToken && config2.token_expiry) {
            isExpired = new Date(config2.token_expiry) < /* @__PURE__ */ new Date();
          }
          return jsonResponse({
            success: true,
            valid: isValidFormat && !isExpired,
            is_stored: isStoredToken,
            is_expired: isExpired,
            format_valid: isValidFormat,
            token_expiry: isStoredToken ? config2.token_expiry : null,
            message: isStoredToken ? isExpired ? "Token expired" : "Token valid" : "Token format valid but not stored"
          });
        } catch (error3) {
          console.error("Token verification error:", error3);
          return errorResponse(`Token verification failed: ${error3.message}`, 500);
        }
      }
      if (path === "/api/verify/oauth-state" && method === "POST") {
        try {
          const body = await request.json();
          const testState = body.state;
          if (!testState) {
            return errorResponse("Missing state parameter", 400);
          }
          const stmt = env2.DB.prepare(
            `SELECT state, created_at, expires_at FROM oauth_states WHERE state = ?`
          );
          const result = await stmt.bind(testState).first();
          if (!result) {
            return jsonResponse({
              success: true,
              exists: false,
              valid: false,
              message: "State not found in database"
            });
          }
          const now = /* @__PURE__ */ new Date();
          const expiresAt = new Date(result.expires_at);
          const isExpired = expiresAt < now;
          return jsonResponse({
            success: true,
            exists: true,
            valid: !isExpired,
            is_expired: isExpired,
            created_at: result.created_at,
            expires_at: result.expires_at,
            message: isExpired ? "State expired" : "State valid"
          });
        } catch (error3) {
          console.error("OAuth state verification error:", error3);
          return errorResponse(`State verification failed: ${error3.message}`, 500);
        }
      }
      if (path === "/api/verify/cleanup-status" && method === "GET") {
        try {
          const expiredStatesStmt = env2.DB.prepare(
            `SELECT COUNT(*) as count FROM oauth_states WHERE expires_at < datetime('now')`
          );
          const expiredStates = await expiredStatesStmt.first();
          const validStatesStmt = env2.DB.prepare(
            `SELECT COUNT(*) as count FROM oauth_states WHERE expires_at >= datetime('now')`
          );
          const validStates = await validStatesStmt.first();
          const totalStatesStmt = env2.DB.prepare(
            `SELECT COUNT(*) as count FROM oauth_states`
          );
          const totalStates = await totalStatesStmt.first();
          return jsonResponse({
            success: true,
            oauth_states: {
              total: totalStates?.count || 0,
              valid: validStates?.count || 0,
              expired: expiredStates?.count || 0
            },
            cleanup_needed: (expiredStates?.count || 0) > 0,
            message: (expiredStates?.count || 0) > 0 ? "Expired states found - cleanup recommended" : "No cleanup needed"
          });
        } catch (error3) {
          console.error("Cleanup status check error:", error3);
          return errorResponse(`Cleanup check failed: ${error3.message}`, 500);
        }
      }
      if (path === "/api/verify/cleanup" && method === "POST") {
        try {
          const stmt = env2.DB.prepare(
            `DELETE FROM oauth_states WHERE expires_at < datetime('now')`
          );
          const result = await stmt.run();
          return jsonResponse({
            success: true,
            deleted: result.meta.changes || 0,
            message: `Cleaned up ${result.meta.changes || 0} expired OAuth states`
          });
        } catch (error3) {
          console.error("Cleanup error:", error3);
          return errorResponse(`Cleanup failed: ${error3.message}`, 500);
        }
      }
      if (path === "/api/gbp/credentials" && method === "POST") {
        try {
          const userId = request.headers.get("X-Encrypted-Yw-ID");
          if (!userId) {
            return errorResponse("User ID required", 401);
          }
          const body = await request.json();
          if (!body.api_key || body.api_key.trim() === "") {
            return errorResponse("API key is required", 400);
          }
          const checkStmt = env2.DB.prepare(
            "SELECT id FROM gbp_config WHERE encrypted_yw_id = ?"
          );
          const existing = await checkStmt.bind(userId).first();
          if (existing) {
            const updateStmt = env2.DB.prepare(
              `UPDATE gbp_config 
               SET api_key = ?, merchant_id = ?, account_id = ?, location_id = ?, 
                   is_configured = 1, updated_at = datetime('now')
               WHERE encrypted_yw_id = ?`
            );
            await updateStmt.bind(
              body.api_key,
              body.merchant_id || null,
              body.account_id || null,
              body.location_id || null,
              userId
            ).run();
          } else {
            const insertStmt = env2.DB.prepare(
              `INSERT INTO gbp_config (encrypted_yw_id, api_key, merchant_id, account_id, location_id, is_configured)
               VALUES (?, ?, ?, ?, ?, 1)`
            );
            await insertStmt.bind(
              userId,
              body.api_key,
              body.merchant_id || null,
              body.account_id || null,
              body.location_id || null
            ).run();
          }
          return jsonResponse({
            success: true,
            message: "GBP credentials saved successfully"
          });
        } catch (error3) {
          console.error("Save GBP credentials error:", error3);
          return errorResponse(`Failed to save credentials: ${error3.message}`, 500);
        }
      }
      if (path === "/api/gbp/credentials" && method === "GET") {
        try {
          const userId = request.headers.get("X-Encrypted-Yw-ID");
          if (!userId) {
            return errorResponse("User ID required", 401);
          }
          const stmt = env2.DB.prepare(
            "SELECT api_key, merchant_id, account_id, location_id, is_configured FROM gbp_config WHERE encrypted_yw_id = ?"
          );
          const config2 = await stmt.bind(userId).first();
          if (!config2) {
            return jsonResponse({
              configured: false,
              has_credentials: false,
              api_key: null,
              merchant_id: null,
              account_id: null,
              location_id: null
            });
          }
          return jsonResponse({
            configured: config2.is_configured === 1,
            has_credentials: true,
            // Return masked API key for security (show last 4 characters only)
            api_key: config2.api_key ? `***${config2.api_key.slice(-4)}` : null,
            merchant_id: config2.merchant_id,
            account_id: config2.account_id,
            location_id: config2.location_id
          });
        } catch (error3) {
          console.error("Get GBP credentials error:", error3);
          return errorResponse(`Failed to retrieve credentials: ${error3.message}`, 500);
        }
      }
      if (path === "/api/gbp/credentials" && method === "DELETE") {
        try {
          const userId = request.headers.get("X-Encrypted-Yw-ID");
          if (!userId) {
            return errorResponse("User ID required", 401);
          }
          const stmt = env2.DB.prepare("DELETE FROM gbp_config WHERE encrypted_yw_id = ?");
          await stmt.bind(userId).run();
          return jsonResponse({
            success: true,
            message: "GBP credentials deleted successfully"
          });
        } catch (error3) {
          console.error("Delete GBP credentials error:", error3);
          return errorResponse(`Failed to delete credentials: ${error3.message}`, 500);
        }
      }
      if (path === "/api/verify/token-refresh" && method === "GET") {
        try {
          const config2 = await getGBPConfig(env2);
          const hasAccessToken = !!config2.access_token;
          const hasRefreshToken = !!config2.refresh_token;
          const hasExpiry = !!config2.token_expiry;
          let canRefresh = false;
          let needsRefresh = false;
          let minutesUntilExpiry = null;
          if (hasExpiry && config2.token_expiry) {
            const expiry = new Date(config2.token_expiry);
            const now = /* @__PURE__ */ new Date();
            minutesUntilExpiry = Math.round((expiry.getTime() - now.getTime()) / (1e3 * 60));
            needsRefresh = minutesUntilExpiry <= 0;
            canRefresh = hasRefreshToken && needsRefresh;
          }
          return jsonResponse({
            success: true,
            has_access_token: hasAccessToken,
            has_refresh_token: hasRefreshToken,
            has_token_expiry: hasExpiry,
            can_refresh: canRefresh,
            needs_refresh: needsRefresh,
            minutes_until_expiry: minutesUntilExpiry,
            token_expiry: config2.token_expiry || null,
            message: canRefresh ? "Token expired and can be refreshed" : needsRefresh ? "Token expired but no refresh token" : "Token valid or no expiry set"
          });
        } catch (error3) {
          console.error("Token refresh check error:", error3);
          return errorResponse(`Refresh check failed: ${error3.message}`, 500);
        }
      }
      return errorResponse("Endpoint not found", 404);
    } catch (error3) {
      console.error("API Error:", error3);
      return errorResponse(error3.message || "Internal server error", 500);
    }
  }
};
export {
  src_default as default
};
//# sourceMappingURL=index.js.map
